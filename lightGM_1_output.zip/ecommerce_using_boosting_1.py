import os
os.system('pip install --quiet lightgbm')                          # [NEW] install lightgbm
 
print("--- Step 1: Importing libraries ---")
import os
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModel
import timm
import torchvision.transforms as T
from PIL import Image
import numpy as np
from tqdm import tqdm
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import shutil
import requests
import time
import lightgbm as lgb                                             # [NEW] import lightgbm
 
# --- Step 2: Configuration for the Kaggle Environment ---
 
print("\n--- Step 2: Setting up configuration ---")
class KaggleConfig:
    
    KAGGLE_INPUT_DIR = Path("/kaggle/input/datasets/bboyattitude/mavericks-amazon-ml-dataset")
    
    KAGGLE_WORKING_DIR = Path("/kaggle/working/")
    IMAGE_DIR = KAGGLE_WORKING_DIR / "images"
    TRAIN_CSV = KAGGLE_INPUT_DIR / "train.csv"
    TEST_CSV = KAGGLE_INPUT_DIR / "test.csv"
 
    # --- Model ---
    TEXT_MODEL_NAME = "distilbert-base-uncased"
    IMAGE_MODEL_NAME = "efficientnet_b0"
    IMG_SIZE = 224
 
    # --- Training 
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    BATCH_SIZE = 64
    EPOCHS = 10
    LEARNING_RATE = 1e-4
    NUM_WORKERS = 2
    
    # --- Image Download ---
    DOWNLOAD_WORKERS = 128
 
    # --- LightGBM ---                                             # [NEW] lgbm config
    LGBM_PARAMS = {
        'objective': 'regression',
        'metric': 'rmse',
        'learning_rate': 0.05,
        'num_leaves': 127,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'verbose': -1,
        'n_jobs': -1,
    }
    LGBM_NUM_ROUNDS = 1000
    LGBM_EARLY_STOPPING = 50
 
# Instantiate the config
config = KaggleConfig()
 
print(f"Device: {config.DEVICE}")
print(f"Train CSV path: {config.TRAIN_CSV}")
print(f"Image directory will be: {config.IMAGE_DIR}")
 
# --- Step 3: High-Speed Image Downloader (with retries) ---
 
print("\n--- Step 3: Defining the image downloader ---")
def download_one_image(args):
    img_url, img_path = args
    if img_path.exists():
        return "skipped"
    # Retry logic
    for attempt in range(3):
        try:
            response = requests.get(img_url, timeout=20)
            response.raise_for_status()
            with open(img_path, 'wb') as f:
                f.write(response.content)
            return "downloaded"
        except requests.exceptions.RequestException:
            time.sleep(1 + attempt) # Simple backoff
            if attempt == 2: return "failed"
 
def download_image_set(csv_path, image_root_dir, set_name, max_workers=16):
    final_save_dir = image_root_dir / set_name
    final_save_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(csv_path)
    tasks = [(row['image_link'], final_save_dir / f"{row['sample_id']}.jpg") for _, row in df.iterrows()]
    print(f"Downloading {len(tasks)} images for '{set_name}' set with {max_workers} workers...")
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(tqdm(executor.map(download_one_image, tasks), total=len(tasks)))
    print(f"Finished '{set_name}' set download. Summary: Skipped={results.count('skipped')}, Downloaded={results.count('downloaded')}, Failed={results.count('failed')}")
 
# --- Step 4: Data Processing (Dataset Class) ---
 
print("\n--- Step 4: Defining the Dataset class ---")
class ProductDataset(Dataset):
    def __init__(self, csv_file, image_dir, tokenizer, is_train=True):
        self.df = pd.read_csv(csv_file)
        self.image_dir = image_dir
        self.is_train = is_train
        self.tokenizer = tokenizer
        self.transform = T.Compose([
            T.Resize((config.IMG_SIZE, config.IMG_SIZE)),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])
 
    def __len__(self):
        return len(self.df)
 
    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        text = str(row['catalog_content'])
        img_folder = 'train' if self.is_train else 'test'
        img_path = self.image_dir / img_folder / f"{row['sample_id']}.jpg"
 
        try:
            image = Image.open(img_path).convert("RGB")
            image = self.transform(image)
        except (FileNotFoundError, OSError):
            image = torch.zeros((3, config.IMG_SIZE, config.IMG_SIZE))
 
        inputs = self.tokenizer(text, padding='max_length', truncation=True, max_length=128, return_tensors='pt')
        input_ids = inputs['input_ids'].squeeze(0)
        attention_mask = inputs['attention_mask'].squeeze(0)
 
        if self.is_train:
            price = float(row['price'])
            target = torch.tensor(np.log1p(price), dtype=torch.float32)
            return {'input_ids': input_ids, 'attention_mask': attention_mask, 'image': image, 'target': target}
        else:
            return {'input_ids': input_ids, 'attention_mask': attention_mask, 'image': image}
 
 
# --- Step 5: Model Architecture ---
 
print("\n--- Step 5: Defining the Model architecture ---")
class MultiModalModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.text_model = AutoModel.from_pretrained(config.TEXT_MODEL_NAME)
        self.image_model = timm.create_model(config.IMAGE_MODEL_NAME, pretrained=True, num_classes=0)
        text_features = self.text_model.config.hidden_size
        image_features = self.image_model.num_features
        self.head = nn.Sequential(nn.Linear(text_features + image_features, 512), nn.ReLU(), nn.Dropout(0.3), nn.Linear(512, 1))
 
    def forward(self, input_ids, attention_mask, image):
        text_output = self.text_model(input_ids=input_ids, attention_mask=attention_mask)
        text_embedding = text_output.last_hidden_state[:, 0, :]
        image_embedding = self.image_model(image)
        combined_features = torch.cat([text_embedding, image_embedding], dim=1)
        output = self.head(combined_features)
        return output
 
    # [NEW] extract combined embeddings WITHOUT passing through the dense head
    def extract_embeddings(self, input_ids, attention_mask, image):
        text_output = self.text_model(input_ids=input_ids, attention_mask=attention_mask)
        text_embedding = text_output.last_hidden_state[:, 0, :]
        image_embedding = self.image_model(image)
        combined_features = torch.cat([text_embedding, image_embedding], dim=1)
        return combined_features                                    # shape: (batch, text_dim + image_dim)
 
 
# [NEW] Helper: run a DataLoader through the frozen NN and collect embeddings + targets
def extract_embeddings_from_loader(model, loader, device, is_train=True):
    model.eval()
    all_embeddings = []
    all_targets = []
    with torch.no_grad():
        for batch in tqdm(loader, desc="Extracting embeddings"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            image = batch['image'].to(device)
            embeddings = model.extract_embeddings(input_ids, attention_mask, image)
            all_embeddings.append(embeddings.cpu().numpy())
            if is_train:
                all_targets.append(batch['target'].numpy())
    X = np.concatenate(all_embeddings, axis=0)
    y = np.concatenate(all_targets, axis=0) if is_train else None
    return X, y
 
 
# --- Step 6: The Main Execution Block (DISK SPACE EFFICIENT) ---
 
if __name__ == '__main__':
    # === STAGE 1: Train NN end-to-end with Dense Head ===
    print("\n--- Step 6.1: Starting TRAINING image download ---")
    download_image_set(config.TRAIN_CSV, config.IMAGE_DIR, 'train', max_workers=config.DOWNLOAD_WORKERS)
    
    print("\n--- Step 6.2: Preparing for training ---")
    tokenizer = AutoTokenizer.from_pretrained(config.TEXT_MODEL_NAME)
    train_dataset = ProductDataset(config.TRAIN_CSV, config.IMAGE_DIR, tokenizer, is_train=True)
    train_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=True, num_workers=config.NUM_WORKERS)
 
    device = torch.device(config.DEVICE)
    model = MultiModalModel().to(device)
    criterion = nn.MSELoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.LEARNING_RATE)
 
    print("\n--- Step 6.3: STAGE 1 — Training NN with dense head to make embeddings price-aware ---")
    model.train()
    for epoch in range(config.EPOCHS):
        loop = tqdm(train_loader, leave=True)
        total_loss = 0
        for batch in loop:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            image = batch['image'].to(device)
            target = batch['target'].to(device)
            optimizer.zero_grad()
            outputs = model(input_ids, attention_mask, image)
            loss = criterion(outputs.squeeze(-1), target)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            loop.set_description(f"Epoch {epoch+1}/{config.EPOCHS}")
            loop.set_postfix(loss=loss.item())
        avg_loss = total_loss / len(train_loader)
        print(f"Epoch {epoch+1} Average Loss: {avg_loss:.4f}")
 
    # === STAGE 2: Freeze NN, extract embeddings, train LightGBM ===  # [NEW]
    print("\n--- Step 6.4: STAGE 2 — Freezing NN and extracting train embeddings ---")
    # Freeze all NN weights — only LightGBM will train from here
    for param in model.parameters():
        param.requires_grad = False
 
    # Need a non-shuffled loader so embeddings align with targets correctly
    embed_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=False, num_workers=config.NUM_WORKERS)
    X_train, y_train = extract_embeddings_from_loader(model, embed_loader, device, is_train=True)
    print(f"Train embeddings shape: {X_train.shape}, Targets shape: {y_train.shape}")
 
    print("\n--- Step 6.5: STAGE 2 — Training LightGBM on extracted embeddings ---")
    # Split 90/10 for early stopping validation
    split_idx = int(len(X_train) * 0.9)
    X_tr, X_val = X_train[:split_idx], X_train[split_idx:]
    y_tr, y_val = y_train[:split_idx], y_train[split_idx:]
 
    lgb_train = lgb.Dataset(X_tr, label=y_tr)
    lgb_val   = lgb.Dataset(X_val, label=y_val, reference=lgb_train)
 
    lgbm_model = lgb.train(
        config.LGBM_PARAMS,
        lgb_train,
        num_boost_round=config.LGBM_NUM_ROUNDS,
        valid_sets=[lgb_train, lgb_val],
        valid_names=['train', 'valid'],
        callbacks=[
            lgb.early_stopping(config.LGBM_EARLY_STOPPING, verbose=True),
            lgb.log_evaluation(period=50)
        ]
    )
    print(f"LightGBM training done. Best iteration: {lgbm_model.best_iteration}")
 
    print("\n--- Step 6.6: Training complete. Deleting train images to free space. ---")
    shutil.rmtree(config.IMAGE_DIR / 'train')
    print("--- Train images deleted. ---")
 
    # === PREDICTION: Extract test embeddings → LightGBM predicts final price ===
    print("\n--- Step 6.7: Starting TEST image download ---")
    download_image_set(config.TEST_CSV, config.IMAGE_DIR, 'test', max_workers=config.DOWNLOAD_WORKERS)
    
    print("\n--- Step 6.8: Extracting test embeddings from frozen NN ---")
    test_dataset = ProductDataset(config.TEST_CSV, config.IMAGE_DIR, tokenizer, is_train=False)
    test_loader  = DataLoader(test_dataset, batch_size=config.BATCH_SIZE, shuffle=False, num_workers=config.NUM_WORKERS)
    X_test, _    = extract_embeddings_from_loader(model, test_loader, device, is_train=False)
    print(f"Test embeddings shape: {X_test.shape}")
 
    print("\n--- Step 6.9: LightGBM predicting final prices ---")  # [NEW] LightGBM does the final prediction
    log_predictions = lgbm_model.predict(X_test, num_iteration=lgbm_model.best_iteration)
    predictions     = np.expm1(log_predictions)                    # inverse of log1p used during training
 
    print("\n--- Step 6.10: Creating submission file ---")
    df_test = pd.read_csv(config.TEST_CSV)
    predictions = predictions[:len(df_test)]
    predictions = np.maximum(0, predictions)
    submission_df = pd.DataFrame({'sample_id': df_test['sample_id'], 'price': predictions})
    
    submission_path = config.KAGGLE_WORKING_DIR / "submission.csv"
    submission_df.to_csv(submission_path, index=False)
 
    print(f"\n--- Pipeline complete! ---")
    print(f"Submission file created at: {submission_path}")
    print("\nFirst 5 predictions:")
    print(submission_df.head())