# src/data_processing.py
import torch
import pandas as pd
from PIL import Image
from torch.utils.data import Dataset
from transformers import AutoTokenizer
import torchvision.transforms as T
import os
import numpy as np


from . import config 

class ProductDataset(Dataset):
    def __init__(self, csv_file, image_dir, is_train=True):
        self.df = pd.read_csv(csv_file)
        self.image_dir = image_dir
        self.is_train = is_train
        self.tokenizer = AutoTokenizer.from_pretrained(config.TEXT_MODEL_NAME)
        self.transform = T.Compose([
            T.Resize((config.IMG_SIZE, config.IMG_SIZE)),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        text = row['catalog_content']
        img_folder = 'train' if self.is_train else 'test'
        img_path = os.path.join(self.image_dir, img_folder, f"{row['sample_id']}.jpg")

        try:
            image = Image.open(img_path).convert("RGB")
            image = self.transform(image)
        except FileNotFoundError:
            print(f"Warning: Image not found at {img_path}. Using placeholder.")
            image = torch.zeros((3, config.IMG_SIZE, config.IMG_SIZE))

        inputs = self.tokenizer(text, padding='max_length', truncation=True, max_length=128, return_tensors='pt')
        input_ids = inputs['input_ids'].squeeze(0)
        attention_mask = inputs['attention_mask'].squeeze(0)

        if self.is_train:
            price = torch.tensor(row['price'], dtype=torch.float32)
            target = torch.log1p(price)
            return {
                'input_ids': input_ids,
                'attention_mask': attention_mask,
                'image': image,
                'target': target
            }
        else:
            return {
                'input_ids': input_ids,
                'attention_mask': attention_mask,
                'image': image,
            }