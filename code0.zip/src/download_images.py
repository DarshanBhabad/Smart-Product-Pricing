# src/download_images.py 
import pandas as pd
import requests
import os
from tqdm import tqdm
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed

def download_one_image(args):
    """Downloads a single image and handles errors."""
    img_url, img_path = args
    if os.path.exists(img_path):
        return "skipped"
    try:
        response = requests.get(img_url, timeout=20)
        response.raise_for_status()
        with open(img_path, 'wb') as f:
            f.write(response.content)
        return "downloaded"
    except requests.exceptions.RequestException:
        return "failed"

def download_image_set(csv_path, image_root_dir, set_name, max_workers=16):
    final_save_dir = os.path.join(image_root_dir, set_name)
    if not os.path.exists(final_save_dir):
        os.makedirs(final_save_dir)
    df = pd.read_csv(csv_path)
    tasks = []
    for _, row in df.iterrows():
        img_url = row['image_link']
        sample_id = row['sample_id']
        img_path = os.path.join(final_save_dir, f"{sample_id}.jpg")
        tasks.append((img_url, img_path))
    print(f"Verifying {len(tasks)} images in '{final_save_dir}' with {max_workers} workers...")
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(tqdm(executor.map(download_one_image, tasks), total=len(tasks)))
    print("\nVerification summary:")
    print(f"Successfully downloaded: {results.count('downloaded')}")
    print(f"Already existed (skipped): {results.count('skipped')}")
    print(f"Failed to download: {results.count('failed')}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Download product images at high speed.")
    parser.add_argument('--mode', type=str, default='full', choices=['sample', 'full'])
    parser.add_argument('--workers', type=int, default=16)
    args = parser.parse_args()

    IMG_DIR = 'data/images/'
 

    if args.mode == 'sample':
        print("--- Verifying SAMPLE data in the main image directory ---")
        TRAIN_CSV = 'data/sample/train_sample.csv'
        TEST_CSV = 'data/sample/test_sample.csv'
    else:
        print("--- Verifying FULL data in the main image directory ---")
        TRAIN_CSV = 'data/raw/train.csv'
        TEST_CSV = 'data/raw/test.csv'

    if not os.path.exists(IMG_DIR):
        os.makedirs(IMG_DIR)

    download_image_set(TRAIN_CSV, IMG_DIR, 'train', max_workers=args.workers)
    download_image_set(TEST_CSV, IMG_DIR, 'test', max_workers=args.workers)
    print(f"\nImage verification complete for {args.mode} mode.")