
import torch
from pathlib import Path
ROOT_DIR = Path(__file__).parent.parent 

DATA_DIR = ROOT_DIR / "data"
SAMPLE_DATA_DIR = DATA_DIR / "sample"
IMAGE_DIR = DATA_DIR / "images"
TRAIN_CSV = SAMPLE_DATA_DIR / "train_sample.csv"
TEST_CSV = SAMPLE_DATA_DIR / "test_sample.csv"

#  Model 
TEXT_MODEL_NAME = "distilbert-base-uncased"
IMAGE_MODEL_NAME = "efficientnet_b0"
IMG_SIZE = 224

#  Training 
DEVICE = "cpu"
BATCH_SIZE = 8
EPOCHS = 2
LEARNING_RATE = 1e-4

# paths
print("--- Configuration Loaded ---")
print(f"Project Root Directory: {ROOT_DIR}")
print(f"Image Directory: {IMAGE_DIR}")
print(f"Train CSV Path: {TRAIN_CSV}")
print(f"Device: {DEVICE}")