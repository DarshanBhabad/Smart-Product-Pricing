# src/model.py
import torch
import torch.nn as nn
from transformers import AutoModel
import timm
from . import config 

class MultiModalModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.text_model = AutoModel.from_pretrained(config.TEXT_MODEL_NAME)

        self.image_model = timm.create_model(
            config.IMAGE_MODEL_NAME, pretrained=True, num_classes=0
        )
        text_features = self.text_model.config.hidden_size
        image_features = self.image_model.num_features
        self.head = nn.Sequential(
            nn.Linear(text_features + image_features, 512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 1) 
        )

    def forward(self, input_ids, attention_mask, image):
        text_output = self.text_model(input_ids=input_ids, attention_mask=attention_mask)
        text_embedding = text_output.last_hidden_state[:, 0, :]
        image_embedding = self.image_model(image)
        combined_features = torch.cat([text_embedding, image_embedding], dim=1)
        output = self.head(combined_features)
        return output